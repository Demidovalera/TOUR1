import React from 'react'

export const Footer = () => {
  return (
    <div>
         <footer className="pt-4 my-md-5 pt-md-5 border-top">
    <div className="row">
      <div className="col-12 col-md">
      
        <img className="mb-2" src="./img/logo.png" alt="" width="150" height="150"/>
       
      </div>
      <div className="col-6 col-md">
        <h5> о нас </h5>
        <ul className="list-unstyled text-small">
          <li className="mb-1"><a className="link-secondary text-decoration-none" href="#">Отличная команда</a></li>
          <li className="mb-1"><a className="link-secondary text-decoration-none" href="#">Условия сотрудничества</a></li>
           </ul>
      </div>
      
    </div>
  </footer>
    </div>
  )
}
