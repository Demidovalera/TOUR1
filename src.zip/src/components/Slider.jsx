import React from 'react'
import Carousel from 'react-bootstrap/Carousel';

const Slider = () => {
  return (
    <div>
    <Carousel >
    <Carousel.Item interval={1000}>
      <img width={'100%'} height={700}
        classNameName="d-block w-100"
        src="./img/first.jpg"
        alt="First slide"
      />
      <Carousel.Caption>
        <h3>ПРОГУЛКИ НА ЯХТЕ</h3>
        <p>Уметь отдыхать – это тоже искусство.</p>
      </Carousel.Caption>
    </Carousel.Item>
    <Carousel.Item interval={500}>
      <img width={'100%'} height={700}
        classNameName="d-block w-100"
        src="./img/three.jpg"
        alt="Second slide"
      />
      <Carousel.Caption>
        <h3>ПЕШИЕ ПРОГУЛКИ В ГОРЫ</h3>
        <p>Тот, кто не умеет отдыхать, не умеет и работать.</p>
      </Carousel.Caption>
    </Carousel.Item>
    <Carousel.Item>
      <img width={'100%'} height={700}
        classNameName="d-block w-100"
        src="./img/banner-new2.jpg"
        alt="Third slide"
      />
      <Carousel.Caption>
        <h3>С ВЫСОТЫ ПТИЧЬЕГО ПОЛЕТА</h3>
        <p>
        Отпуск предназначен для того, чтобы забыть обо всем. Некоторые из нас справляются с этим лучше других и амнезия начинает их одолевать еще на этапе сбора чемодана.
        </p>
      </Carousel.Caption>
    </Carousel.Item>
  </Carousel>
  </div>
  )
}

export default Slider