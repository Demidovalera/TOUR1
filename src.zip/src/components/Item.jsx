import React from 'react'
import Container from 'react-bootstrap/Container'
import '../App.css'


const Item = () => {
  return (
    <div className='conteiner py-3'>
      <main>
        <div CLASSnAME='row-cols-1 row-colsmd-3 row-cols-2 text-center'>
          <div className='col py-3'>
            <div className='card md-6 rounded'>
              <div className='card-header'>
                <div>
                  <p>ОТДЫХ НА МОРСКОМ ПОБЕРЕЖЬЕ</p>
                  <img className='rounded' src='img/1.jpg' width='85%'>
                  </img>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default Item